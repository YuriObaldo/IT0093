//
//  DetailViewController.swift
//  CampusCompanion
//

import UIKit
import MapKit
import CoreLocation

class DetailViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var campusMapView: MKMapView!
    @IBOutlet weak var distanceLabel: UILabel!

    // Keep the lab's original reference coordinate as the distance destination.
    private enum CampusLocation {
        static let coordinate = CLLocationCoordinate2D(latitude: 14.6255, longitude: 121.0034)
    }

    private enum LibraryLocation {
        // Example nearby landmark for the exercise, not a verified building location.
        static let coordinate = CLLocationCoordinate2D(latitude: 14.6263, longitude: 121.0042)
    }

    // Retain the manager until its authorization and one-shot location callbacks arrive.
    private let locationManager = CLLocationManager()
    private var lastAuthorizationStatus: CLAuthorizationStatus?
    private var lastMapSize: CGSize = .zero
    private var landmarkAnnotations: [MKPointAnnotation] = []

    var studentName: String = ""
    var notificationsEnabled: Bool = false
    var selectedRole: String = ""
    var eventDate: Date = Date()
    var guestCount: Int = 1

    var announcement: CampusAnnouncement?

    override func viewDidLoad() {
        super.viewDidLoad()
        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center

        if let announcement = announcement {
            // Core Data generates String? properties, so unwrap each with a safe default.
            let announcementTitle = announcement.title ?? ""
            let category = announcement.category ?? ""
            let date = announcement.date ?? ""
            let priority = announcement.priority ?? "Normal"
            let location = announcement.location ?? "Not specified"
            let postedBy = announcement.postedBy ?? ""

            title = category
            messageLabel.text = """
            \(announcementTitle)

            Category: \(category)
            Date: \(date)
            Location: \(location.isEmpty ? "Not specified" : location)
            Priority Level: \(priority)
            Posted by: \(postedBy)
            """
        } else {
            title = "Campus Events"
            let notificationStatus = notificationsEnabled ? "on" : "off"

            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            formatter.timeStyle = .none

            messageLabel.text = """
            Welcome, \(studentName)! (\(selectedRole))
            Notifications: \(notificationStatus).
            Event: \(formatter.string(from: eventDate))
            Guests: \(guestCount)
            """
        }

        configureCampusMap()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        updateLocationAuthorization(locationManager)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Fit both landmarks after Auto Layout and again if rotation changes the map size.
        let mapSize = campusMapView.bounds.size
        guard mapSize.width > 0, mapSize.height > 0, mapSize != lastMapSize else { return }
        lastMapSize = mapSize
        campusMapView.showAnnotations(landmarkAnnotations, animated: false)
    }

    private func configureCampusMap() {
        campusMapView.delegate = self
        let region = MKCoordinateRegion(
            center: CampusLocation.coordinate,
            latitudinalMeters: 500,
            longitudinalMeters: 500
        )
        campusMapView.setRegion(region, animated: false)

        let campusAnnotation = MKPointAnnotation()
        campusAnnotation.coordinate = CampusLocation.coordinate
        campusAnnotation.title = "Campus"

        let libraryAnnotation = MKPointAnnotation()
        libraryAnnotation.coordinate = LibraryLocation.coordinate
        libraryAnnotation.title = "Campus Library"
        libraryAnnotation.subtitle = "Example nearby landmark"

        landmarkAnnotations = [campusAnnotation, libraryAnnotation]
        campusMapView.addAnnotations(landmarkAnnotations)
    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard annotation is MKPointAnnotation else { return nil }
        let identifier = "CampusLandmark"
        let marker = (mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
                      as? MKMarkerAnnotationView)
            ?? MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
        marker.annotation = annotation
        marker.canShowCallout = true
        marker.titleVisibility = .visible
        // Keep both pins visible rather than allowing MapKit to suppress a nearby marker.
        marker.displayPriority = .required
        let isLibrary = annotation.title == "Campus Library"
        marker.markerTintColor = isLibrary ? .systemPurple : .systemBlue
        marker.glyphImage = UIImage(systemName: isLibrary ? "books.vertical.fill" : "building.2.fill")
        return marker
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        updateLocationAuthorization(manager)
    }

    private func updateLocationAuthorization(_ manager: CLLocationManager) {
        let status = manager.authorizationStatus
        // Setting a delegate can deliver the initial status as well as the explicit setup call.
        guard status != lastAuthorizationStatus else { return }
        lastAuthorizationStatus = status

        switch status {
        case .notDetermined:
            distanceLabel.text = "Allow location access to see your distance from campus."
            manager.requestWhenInUseAuthorization()
        case .authorizedWhenInUse, .authorizedAlways:
            distanceLabel.text = "Finding your distance from campus…"
            manager.requestLocation()
        case .denied:
            distanceLabel.text = "Location access denied. Enable it in Settings to see your distance from campus."
        case .restricted:
            distanceLabel.text = "Location access is restricted on this device."
        @unknown default:
            distanceLabel.text = "Location access is currently unavailable."
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let currentLocation = locations.last, currentLocation.horizontalAccuracy >= 0 else {
            distanceLabel.text = "Your location is unavailable. Reopen this screen to try again."
            return
        }
        // Deliberately independent of annotation order, selection, and LibraryLocation.
        let campusLocation = CLLocation(
            latitude: CampusLocation.coordinate.latitude,
            longitude: CampusLocation.coordinate.longitude
        )
        let distanceInMeters = currentLocation.distance(from: campusLocation)
        distanceLabel.text = String(
            format: "You are approximately %.0f meters from campus.", distanceInMeters
        )
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Campus location: \(error.localizedDescription)")
        switch manager.authorizationStatus {
        case .denied:
            distanceLabel.text = "Location access denied. Enable it in Settings to see your distance from campus."
        case .restricted:
            distanceLabel.text = "Location access is restricted on this device."
        case .notDetermined, .authorizedWhenInUse, .authorizedAlways:
            distanceLabel.text = "Your location is unavailable. Reopen this screen to try again."
        @unknown default:
            distanceLabel.text = "Location access is currently unavailable."
        }
    }
}
